let g_current_profile_set = null;

function on_document_click(e) {
  const target = e.target;
  // Ignore clicks on the currently selected marker
  if (target.closest('.marker-current')) return;
  const classes = target.classList;
  if (classes.contains('profile')) {
    let button = classes.contains('button') ? target : target.parentNode;
    chrome.runtime.sendMessage({
      msg: 'change-profile-current',
      index: button.getAttribute('data-profile-index')
    }).catch(() => {});
    window.close();
    return;
  }
  if (target.closest('#button_options')) {
    chrome.runtime.openOptionsPage();
    window.close();
    return;
  }
  if (target.closest('#button_enable_disable')) {
    chrome.runtime.sendMessage({msg: 'change-enabled'}).catch(() => {});
    window.close();
    return;
  }
  const markerWrapper = target.closest('.marker-wrapper');
  if (markerWrapper) {
    const marker = [...markerWrapper.classList]
      .find(c => /^marker-\d+$/.test(c));
    if (marker) {
      chrome.runtime.sendMessage({
        msg: 'change-marker-image',
        marker_image: Number(marker.split('-')[1])
      }).catch(() => {});
    }
    window.close();
    return;
} }

function on_document_keyup(e){
//if(event.key === 'Control') document.title = 'Control';	
}

function create_unknown_browser_button(){
  let button = document.createElement('div');
  let class_list = 'button unknown';
  button.setAttribute('class', class_list);
  button.innerText = chrome.i18n.getMessage('unknown_browser');
  let root = document.getElementById('root');
  root.appendChild(button);
}

function create_profile_button(name, index, is_current) {
  let label = document.createElement('label');
  let button = document.createElement('div');
  let class_list = 'button profile';
  if(is_current) class_list += ' current';
  button.setAttribute('class', class_list);
  button.setAttribute('data-profile-index', index);
  let spacer = document.createElement('div');
  let spacer_class = 'spacer profile';
  if(is_current) spacer_class += ' bull';
  spacer.setAttribute('class', spacer_class);
  button.appendChild(spacer);
  let span = document.createElement('span');
  span.setAttribute('class', 'label profile');
  span.innerText = name;
  button.appendChild(span);
  let tail = document.createElement('span');
  tail.setAttribute('class', 'tail profile');
  button.appendChild(tail);
  let root = document.getElementById('root');
  root.appendChild(label);
  root.appendChild(button);
}

function show_as_enabled() {
  document.getElementById('button_enable_disable').classList.add('tick');
}

function set_marker_image(marker_image) {
  let marker_wrapper = document.getElementById('marker_wrapper_' + marker_image);
  if(marker_wrapper) marker_wrapper.classList += ' marker-current';
}

function on_messages_popup(request, sender, sendResponse) {
  if(sender.id !== chrome.runtime.id) return;
  if(request.msg === 'set-profile-set') {
    g_current_profile_set = request.profile_set;
    if(request.browser_supported === 0) create_unknown_browser_button();
    const current_profile_index = parseInt(g_current_profile_set.curr);
    for(let i=0; i<g_current_profile_set.name.length; i++) {
      let menu_name = g_current_profile_set.name[i];
      create_profile_button(menu_name, i, i === current_profile_index);
    }
    if(g_current_profile_set.enabled) show_as_enabled();
    const enabled = g_current_profile_set.enabled;
    const button = document.getElementById('button_enable_disable');
    const label = document.getElementById('label_enable_disable');
    label.innerText = chrome.i18n.getMessage(
      enabled ? 'popup_menu_enabled' : 'popup_menu_disabled'
    );
    button.title = chrome.i18n.getMessage(
      enabled ? 'popup_tooltip_enabled' : 'popup_tooltip_disabled'
    );
    set_marker_image(g_current_profile_set.marker_image);
    const img = document.getElementById('marker_wrapper_0');
    img.title = chrome.i18n.getMessage('popup_tooltip_no_marker');
    document.getElementById('button_options').title =
      chrome.i18n.getMessage('popup_menu_options_tip');
    document.getElementById('label_options').innerText =
      chrome.i18n.getMessage('popup_menu_options');
    document.getElementById('profiles').innerText =
      chrome.i18n.getMessage('popup_menu_profiles');
    document.getElementById('preferences').innerText =
      chrome.i18n.getMessage('popup_menu_preferences');
    document.getElementById('marker_options').innerText =
      chrome.i18n.getMessage('popup_menu_markeroptions');
} }

chrome.runtime.onMessage.addListener(on_messages_popup);
chrome.runtime.sendMessage({msg:'get-profile-set'}).catch(() => {});
chrome.tabs.query({ currentWindow: true, active: true }, function (tabs) {
  if (!tabs.length || !tabs[0].id) return;
  chrome.tabs.sendMessage(tabs[0].id, {msg:'close-menu'}).catch(() => {});
});

document.addEventListener('click', on_document_click);
document.addEventListener('keyup', on_document_keyup);

let browser_lang = chrome.i18n.getUILanguage();
if(browser_lang.indexOf('ar') === 0 || browser_lang.indexOf('fa') === 0 ||
   browser_lang.indexOf('he') === 0 || browser_lang.indexOf('ur') === 0) document.body.style.direction = 'rtl';