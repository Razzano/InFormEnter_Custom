const EXCLUDED_INPUTS = [ // For is_marker_excluded(input) Line 104
  '#scalerInput', // Google Dashboard
  '#inputLogo', // Google Dashboard
  '#id-query-input', // YouTubeTV
  'textarea[aria-label="Search"]', // Google Dashboard
  'textarea[name="search_query"]', // YouTube
  'input[aria-label="Search mail"]', // Gmail
  'input[aria-label="Search Amazon"]', // Amazon
  'input[aria-label="Search all orders"]', // Amazon
  'input[aria-label="Search Facebook"]', // Facebook
  'input.EmSKud', // Google Maps
  'input[placeholder^="Search Scripts"]', // OpenUserJS
  'input[data-no-marker]',
  '.no-marker',
  '[name="username"]',
  '[class="exclude-marker"]',
];

let g_macro_style = ["$Bold$", "$Big$", "$Red$", "$Green$", "$Blue$"];
let g_macro_class = ["informenter-macro-bold", "informenter-macro-big",
    "informenter-macro-red", "informenter-macro-green", "informenter-macro-blue"];

function extract_menu_name(line_str) {
	let menu_name = line_str;
	let pos = line_str.lastIndexOf("##");
	if (pos !== -1) menu_name = line_str.substr(pos+2);
	return menu_name;
}

function extract_menu_value(line_str) {
	let menu_value = line_str;
	let pos = line_str.lastIndexOf("##");
	if (pos !== -1) menu_value = line_str.substr(0, pos);
	menu_value = menu_value.replace(/@@/g, "\n");
	menu_value = macro_convert(menu_value);
	return menu_value;
}

function extract_menu_style(line_str) {
	let menu_style = "";
	for (let i = 0; i < g_macro_style.length; i++) {
		let current_macro = g_macro_style[i];
		if (line_str.indexOf(current_macro) !== -1) {
			let current_class = g_macro_class[i];
			if (menu_style.indexOf(current_class) === -1) menu_style += " " + current_class;
	}   }
	return menu_style;
}

function clear_menu_style(line_str) {
	for (let i = 0; i < g_macro_style.length; i++) {
		let current_macro = g_macro_style[i];
		while (line_str.indexOf(current_macro) !== -1) line_str = line_str.replace(current_macro, "");
	}
	return line_str;
}

function menu_value_is_valid(menu_value) {
	if (menu_value.indexOf("---") === 0) return false;
	return true;
}

let g_img_marker = null;
let g_input_current = null;
let g_neighbors_below = 0;
let g_menu_items = null;
let g_menu_x = 0;
let g_menu_y = 0;
let g_menu_index_selected = -1;
let g_enabled = 0;
let g_marker_location = 0;
let g_marker_image = 1;
let g_last_password = "";
let g_shift_is_pressed = 0;
let g_ctrl_is_pressed = 0;
let g_marker_shifting = 0;
let g_marker_recreate = 0;
let g_browser_supported = 1;

function is_input(element) {
	let node_name = element.nodeName.toString().toUpperCase();
	let result = (node_name === "INPUT" || node_name === "TEXTAREA");
	return result;
}

function is_input_editable(input) {
	//if (input.matches(EXCLUDED_INPUTS.join(', '))) return false;
	if (input.offsetWidth < 2) return false; // hidden input
	let result = true;
	let type = input.getAttribute("type");
	if (type !== null) {
	  type = type.toString().toLowerCase();
	  if (type === "button" || type === "checkbox" || type === "file" ||
		  type === "hidden" || type === "image" || type === "radio" ||
		  type === "reset" || type === "submit" || type === "range") result = false;
	}
	if (result) {
	  if (typeof(input.disabled) !== 'undefined' && input.disabled) result = false;
	  if (typeof(input.readOnly) !== 'undefined' && input.readOnly) result = false;
	}	
	return result;
}

function is_marker_excluded(input) {
  return input.matches(EXCLUDED_INPUTS.join(', '));
}

function check_contenteditable_element() {
	let element = document.activeElement;
	while (element && element.getAttribute) {
		let contenteditable = element.getAttribute("contenteditable");
		if (contenteditable !== null && contenteditable === "true") {
			g_input_current = element;
			break;
		}
		element = element.parentNode;
}   }

function calc_neighbors_below() {
	g_neighbors_below = 0;
	let element_index = get_index_in_form();
	if (element_index === -1) return;
	let form_items = g_input_current.form.elements;
	for (let i = element_index + 1; i < form_items.length; i++) {
		let element = form_items.item(i);
		if (is_input(element) && is_input_editable(element)) g_neighbors_below++;
}	}

function get_clipboard_text() {
	let et = null;
	let text = null;
	let is_Firefox = navigator.userAgent.indexOf("Gecko/") !== -1;
	if (is_Firefox) {
		et = document.createElement("div");
		et.setAttribute("contenteditable", "true");
	}
	else et = document.createElement("textarea");
	et.setAttribute("style", "position: absolute; top: -3000px; left: -3000px;");
	document.body.appendChild(et); 
	et.focus();
	document.execCommand("paste");
	if (is_Firefox) text = et.innerText;
	else text = et.value;
	document.body.removeChild(et); 
	return text;
}

function on_input_select(event) {
	let menu_wrap = document.getElementById("informenter-menu");
	if (menu_wrap) return;
	marker_show(event.currentTarget);
	calc_neighbors_below();
}

function on_document_click(event) { 
	let element = event.target;
	if (is_input(element) && is_input_editable(element)) marker_show(element);
	else if (!(event.button === 2 && element.classList.contains("informenter-marker-show"))) marker_hide_anywhere();
	menu_off();
}

function on_document_keydown(event) { 
	if (g_enabled) {
		let menu_wrap = document.getElementById("informenter-menu");
		if (menu_wrap) {		
			if (event.key === "Escape" || event.key === "Enter" || event.key === "ArrowUp" || event.key === "ArrowDown") {
				if (event.key === "Escape") menu_off();
				if (event.key === "ArrowUp") menu_select_prev();
				if (event.key === "ArrowDown") menu_select_next();
				if (event.key === "Enter") menu_select_current(event.shiftKey, event.ctrlKey);
				event.preventDefault();
		}   }
		if (event.key === "Shift") {
			g_shift_is_pressed = 1;
			menu_item_neighbors_show();
		}
		if (event.key === "Control") g_ctrl_is_pressed = 1;
}   }

function on_document_keyup(event) {
	if (g_enabled) {
		if (event.key === "Shift") {
			g_shift_is_pressed = 0;
			menu_item_neighbors_hide();
		}
		if (event.key === "Control") g_ctrl_is_pressed = 0;
}	}

function on_window_beforeprint(event) {
	if (g_img_marker !== null) {
		marker_remove();
		g_marker_recreate = 1;
}   }

function on_window_afterprint(event) {
	if (g_marker_recreate === 1) marker_create();
}

function on_window_scroll(event) {
	let menu_wrap = document.getElementById("informenter-menu");
	if (menu_wrap === null) marker_hide_on_page();
}

function on_window_resize(event) {
	menu_off();
	marker_hide_on_page();
}

function marker_create() {
	g_img_marker = document.getElementById("informenter-marker-id");
	if (g_img_marker === null && g_marker_image > 0) {
		g_img_marker = document.createElement("img");
		g_img_marker.setAttribute("src", chrome.runtime.getURL("img/marker-"+g_marker_image+".png"));
		g_img_marker.setAttribute("class", "informenter-marker-hide");
		g_img_marker.setAttribute("style", "");
		g_img_marker.setAttribute("id", "informenter-marker-id");
		g_img_marker.setAttribute("title", chrome.i18n.getMessage("marker_right_click_hint"));
		let contenteditable = document.body.getAttribute("contenteditable");
		if (contenteditable !== true && contenteditable !== "true" && contenteditable !== "") {
			document.body.appendChild(g_img_marker);
			g_img_marker.addEventListener("click", on_marker_click);
			g_img_marker.addEventListener("contextmenu", on_marker_contextmenu);
		} else g_img_marker = null;
}   }

function marker_remove() {
	g_img_marker = document.getElementById("informenter-marker-id");
	if (g_img_marker !== null) {
		g_img_marker.parentNode.removeChild(g_img_marker);
		g_img_marker = null;
}   }

function marker_show(input) {
	g_input_current = input;
	g_neighbors_below = 0;
	if (is_marker_excluded(input)) {
      if (g_img_marker !== null) g_img_marker.className = "informenter-marker-hide";
      return;
    }
	if (g_img_marker === null) return;
	let rect_input = g_input_current.getBoundingClientRect();
	// location === 0
	let top = window.scrollY + rect_input.top;
	if (g_input_current.nodeName.toString().toUpperCase() === "INPUT")
		top += (rect_input.height - g_img_marker.naturalHeight) / 2;
	let left = window.scrollX + rect_input.left + rect_input.width;
	if (g_marker_location === 1) left = window.scrollX + rect_input.left + rect_input.width - g_img_marker.naturalWidth;
	if (g_marker_location === 2) top = window.scrollY + rect_input.top + g_img_marker.naturalHeight;
	if (g_marker_location === 3) left = window.scrollX + rect_input.left - g_img_marker.naturalWidth;
	let scrollbar_width = 20;
	if (left > window.innerWidth - scrollbar_width - g_img_marker.naturalWidth)
		left = window.innerWidth - scrollbar_width - g_img_marker.naturalWidth;
	let style_str = "top: " + top + "px; left: " + left + "px;";
	if (g_enabled) g_img_marker.className = "informenter-marker-show";
	else g_img_marker.className = "informenter-marker-hide";
	g_img_marker.style = style_str;
}

function marker_hide_anywhere() {
	chrome.runtime.sendMessage({msg:"hide-marker-anywhere"});
}

function marker_hide_on_page() {
	if (g_img_marker) g_img_marker.className = "informenter-marker-hide";
	g_input_current = null;
	g_neighbors_below = 0;
}

// mouseover
let list = document.getElementsByTagName("input");
for (let i = 0; i < list.length; i++) {
	if (is_input_editable(list.item(i))) {
		list.item(i).addEventListener("mouseover", on_input_select);
		list.item(i).addEventListener("focus", on_input_select);
}   }

list = document.getElementsByTagName("textarea");
for (let i = 0; i < list.length; i++) {
	if (is_input_editable(list.item(i))) {
		list.item(i).addEventListener("mouseover", on_input_select);
		list.item(i).addEventListener("focus", on_input_select);
}   }

function create_menu_wrap() {
	let menu_wrap = document.getElementById("informenter-menu");
	if (menu_wrap) menu_wrap.parentNode.removeChild(menu_wrap);
	menu_wrap = document.createElement("div");
	menu_wrap.setAttribute("id", "informenter-menu");
	let style_str = "";
	let browser_lang = chrome.i18n.getUILanguage();
	if (browser_lang.indexOf("ar") === 0 || browser_lang.indexOf("he") === 0) style_str = "direction: rtl; ";
	style_str += "top: " + g_menu_y + "px; left: " + g_menu_x + "px;";
	menu_wrap.setAttribute("style", style_str);
	document.body.appendChild(menu_wrap);
	return menu_wrap;
}

function create_menu_item(menu_wrap, name, index, menu_style) {
	let menu_item = null;
	if (name.indexOf("---") === 0) menu_item = document.createElement("hr");
	else {
		menu_item = document.createElement("div");
		menu_item.setAttribute("class", "informenter-menu-item"+menu_style);
		menu_item.setAttribute("tabindex", "-1");
		if (index === 65536) {
			if (g_input_current.value.length === 0) {
				menu_item.setAttribute("class", "informenter-menu-item-to-add-disabled");
			}
			else {	
				menu_item.setAttribute("class", "informenter-menu-item-to-add");
				let menu_item_title = chrome.i18n.getMessage("marker_menu_add_to_profile_hint");
				menu_item.setAttribute("title", menu_item_title);
		}   }
		menu_item.setAttribute("data-menu-index", index);
		let id = "informenter-menu-item-" + index;
		menu_item.setAttribute("id", id);
		let hotkeys_limit = 9;
		let hotkeys_prefix = "Ctrl+";
		if (navigator.userAgent.indexOf("Gecko/") === -1) {
			hotkeys_limit = 3;
			hotkeys_prefix = "Ctrl+Shift+";
		}
		if (index < hotkeys_limit) {
			let menu_num = index+1;
			menu_item.setAttribute("title", hotkeys_prefix+menu_num); 
		}
		let menu_name = name;
		if (menu_name.length > 70) { 
			menu_name = name.substr(0, 70);
			menu_name += "...";
		}
		menu_item.textContent = menu_name; 
		menu_item.addEventListener("click", on_menu_item_click);
		menu_item.addEventListener("mouseover", on_menu_item_over);
		menu_item.addEventListener("mouseout", on_menu_item_out);
	}
	menu_wrap.appendChild(menu_item); 
}

function create_menu_special_items(menu_wrap) {
	let menu_separator = document.createElement("hr");
	menu_wrap.appendChild(menu_separator); 
	let menu_special_name = chrome.i18n.getMessage("marker_menu_add_to_profile");
	create_menu_item(menu_wrap, menu_special_name, 65536, "");
}

function check_menu_position(menu_wrap) {
	let scrollbar_width = 20;
	let menu_width = menu_wrap.offsetWidth;
	if (g_menu_x + menu_width > window.innerWidth - scrollbar_width) {
		let left = window.innerWidth - menu_width - scrollbar_width;
		menu_wrap.style.left = left+"px";
	}
	if (menu_width > g_menu_x && menu_width > window.innerWidth/2 && g_menu_x > window.innerWidth/2) { // 0.849
		let left = 0;
		let width = g_menu_x;
		menu_wrap.style.left = left+"px";
		menu_wrap.style.width = width+"px";
	}
	let menu_height = menu_wrap.offsetHeight;
	if (g_menu_y - window.scrollY + menu_height > window.innerHeight) { 
		let top = window.scrollY + window.innerHeight - menu_height;
		menu_wrap.style.top = top + "px";
	}
	if (menu_height > window.innerHeight) {
		menu_wrap.style.top = window.scrollY + "px";	
		let menu_height_new = window.innerHeight - 20;
		menu_wrap.style.height = menu_height_new + "px";	
		menu_wrap.style.overflow = "auto";
}   }

function macro_convert(menu_value) {
	let new_value = menu_value;
	let macro = "$GeneratePassword";
	while (new_value.indexOf(macro) !== -1) {
		let password = "";
		let pos1 = new_value.indexOf(macro);
		let part_head = new_value.substr(0, pos1);
		pos1 += macro.length;
		let pos2 = new_value.indexOf("$", pos1);
		if (pos2 !== -1) {
			let option_str = new_value.substring(pos1, pos2);
			option_str = option_str.replace(/ /g, "");
			let option_arr = option_str.split(",");
			let option_data = {length:0, U:0, L:0, N:0, S:0, X:0, C:0, specials:""};
			for (let item_data of option_arr) {
				if (item_data.length) {
					let item_1 = item_data.substr(0,1);
					if (parseInt(item_1)) {
						option_data.length = parseInt(item_data);
						if (option_data.length < 3) option_data.length = 3;
						if (option_data.length > 1024) option_data.length = 1024;
					} else {
						let item_2 = 1;
						if (item_data.length > 1) {
							let item_2 = parseInt(item_data.substr(1));
							if (isNaN(item_2)) {
								if (item_1 === "S") item_2 = 1;
								else continue;
							}
							if (item_2 < 1) item_2 = 1;
							if (item_2 > 128) item_2 = 128;
						}
						switch (item_1) {
							case 'U': option_data.U = item_2; break;
							case 'L': option_data.L = item_2; break;
							case 'N': option_data.N = item_2; break;
							case 'S': option_data.S = item_2; break;
							case 'X': option_data.X = item_2; break;
							case 'C': option_data.C = item_2; break;
						}
						if (item_1 === "S") {
							let head = "S" + option_data.S;
							let tail = item_data.replace(head, ""); // case "S1#@"
							if (tail.length && tail[0] === "S") tail = tail.substr(1); // case "S#@"
							if (tail.length) {
								tail = tail.replace("Comma", ",");
								tail = tail.replace("Dollar", "$");
								option_data.specials = tail;	
			}   }   }   }   }
			password = generate_password(option_data);
			g_last_password = password;
			chrome.runtime.sendMessage({msg:"set-last-password", password:password});
			if (option_data.C) copy_to_clipboard(password);
		}
		else pos2 = pos1;
		let part_tail = new_value.substr(pos2+1);
		new_value = part_head + password + part_tail;
	}
	macro = "$LastPassword$";
	while (new_value.indexOf(macro) !== -1) new_value = new_value.replace(macro, g_last_password);
	macro = "$OldText$";
	while (new_value.indexOf(macro) !== -1) {
		let old_value = "";
		if (g_input_current !== null) old_value = g_input_current.value;
		new_value = new_value.replace(macro, old_value);
	}	
	macro = "$RandomText,";
	while (new_value.indexOf(macro) !== -1) {
		let pos1 = new_value.indexOf(macro);
		let part_head = new_value.substr(0, pos1);
		let part_text = "";
		pos1 += macro.length;
		let pos2 = new_value.indexOf("$", pos1);
		if (pos2 !== -1) {
			let variants_str = new_value.substring(pos1, pos2);
			let variants_arr = variants_str.split(",");
			if (variants_arr.length) {
				let index_random = Math.floor(Math.random() * variants_arr.length);
				part_text = variants_arr[index_random];	
				part_text = part_text.replace("Comma", ",");
				part_text = part_text.replace("Dollar", "$");
		}   }
		let part_tail = new_value.substr(pos2 + 1);
		new_value = part_head + part_text + part_tail;			
	}	
	macro = "$ClipboardText$";
	if (new_value.indexOf(macro) !== -1) {
		let clipboard_text = get_clipboard_text();
		while (new_value.indexOf(macro) !== -1) new_value = new_value.replace(macro, clipboard_text);
	}
	return new_value;
}

function generate_password(option_data) {
	let password = "";
	let length_wanted = option_data.length;
	let length_by_parts = option_data.U + option_data.L + option_data.N + option_data.S;
	let length_by_parts_is_strong = 0;
	if (option_data.U > 1 || option_data.L > 1 || option_data.N > 1 || option_data.S > 1)
		length_by_parts_is_strong = 1;
	if (length_by_parts === 0 && length_wanted === 0) { // $GeneratePassword$
		option_data.U = 4;
		option_data.L = 4;
		option_data.N = 4;
		length_wanted = 12;	length_by_parts = 12;
	}
	if (length_by_parts === 0 && length_wanted !== 0) { // $GeneratePassword,10$
		option_data.U = 1;
		option_data.L = 1;
		option_data.N = 1;
		length_by_parts = 3;
	}
	if (length_by_parts !== 0 && length_wanted === 0) length_wanted = 12; // $GeneratePassword,U,L,N$
	if (length_by_parts && length_wanted > length_by_parts && length_by_parts_is_strong === 0) {
		while (1) {
			if (option_data.U) {
				option_data.U++;
				length_by_parts++;
				if (length_by_parts >= length_wanted) break;
			}
			if (option_data.L) {
				option_data.L++;
				length_by_parts++;
				if (length_by_parts >= length_wanted) break;
			}
			if (option_data.N) {
				option_data.N++;
				length_by_parts++;
				if (length_by_parts >= length_wanted) break;
			}
			if (option_data.S) {
				option_data.S++;
				length_by_parts++;
				if (length_by_parts >= length_wanted) break;
	}   }   }
	// validate parts
	let set_U = "ABCDEFGHIJKLMNPQRSTUVWXYZ";
	if (option_data.X === 0) set_U += "O";
	let set_L = "abcdefghijklmnpqrstuvwxyz";
	if (option_data.X === 0) set_L += "o";
	let set_N = "123456789";
	if (option_data.X === 0) set_L += "0";
	let set_S = "~!?@#№$%^*()<>[]{}_-+=";
	if (option_data.specials.length) set_S = option_data.specials;
	// generate password
	if (option_data.U) password += select_random_elements(set_U, option_data.U);  
	if (option_data.L) password += select_random_elements(set_L, option_data.L);  
	if (option_data.N) password += select_random_elements(set_N, option_data.N);  
	if (option_data.S) password += select_random_elements(set_S, option_data.S);  
	// shuffle
	for (let i = 0; i < 16; i++) {
		let head = "";
		let tail = password;
		if (option_data.U || option_data.L) {
			head = password.substr(0, 1);
			tail = password.substr(1);
		}
		tail = tail.split('').sort(function(){return 0.5 - Math.random()}).join('');
		password = head + tail;
	}
	return password;
}

function select_random_elements(str, count) {
	let result = "";
	let arr = str.split("");
	let allow_splice = arr.length > count;
	for(let i = 0; i < count; i++) {
		let index_random = Math.floor(Math.random() * arr.length);
		result += arr[index_random];
		if (allow_splice) arr.splice(index_random, 1);
	}
	return result;
}

function copy_to_clipboard(text) {
	if (document.queryCommandSupported && document.queryCommandSupported("copy")) {
        let textarea = document.createElement("textarea");
        textarea.textContent = text;
        textarea.style.position = "fixed"; 
        document.body.appendChild(textarea);
        textarea.select();
        try {
            return document.execCommand("copy");
        } catch (ex) {
            console.warn("Copy to clipboard failed.", ex);
            return false;
        } finally {
            document.body.removeChild(textarea);
}   }   }

function menu_item_insert(menu_index, is_shift_key, is_ctrl_key) {
	if (menu_index > -1 && menu_index < g_menu_items.length) {
		if (is_shift_key) {
			insert_to_form_index(menu_index);
			return;
		}
		let line_str = g_menu_items[menu_index];
		line_str = clear_menu_style(line_str);
		let menu_value = extract_menu_value(line_str);
		if (menu_value_is_valid(menu_value)) insert_to_input(menu_value, is_ctrl_key);
}   }

function get_index_in_form() {
	let form_is_valid = 1;
	let name_curr = g_input_current.getAttribute("name");
	if (name_curr === null || typeof(name_curr) === 'undefined') name_curr = g_input_current.getAttribute("id");
	if (name_curr === null || typeof(name_curr) === 'undefined') form_is_valid = 0;
	if (g_input_current.form === null) form_is_valid = 0;
	if (form_is_valid === 0) return -1;
	// search current	
	let index_curr = -1;
	let form_items = g_input_current.form.elements;
	for (let i = 0; i < form_items.length; i++) {
		let element = form_items.item(i);
		let element_name = element.getAttribute("name");
		let element_id = element.getAttribute("id");
		if (name_curr === element_name || name_curr === element_id) {
			index_curr = i;
			break;		
	}   }
	return index_curr;
}

function insert_to_form_value(menu_value) {
	let element_index = get_index_in_form();
	if (element_index === -1) {
		g_input_current.value = menu_value;
		send_input_events(g_input_current);
		return;
	}
	let value_arr = menu_value.split("~~");
	let value_arr_curr = 0;
	// fill form
	let form_items = g_input_current.form.elements;
	for (let i = element_index; i < form_items.length && value_arr_curr<value_arr.length; i++) {
		let element = form_items.item(i);
		if (is_input(element) && is_input_editable(element)) {
			element.value = validate_menu_value(value_arr[value_arr_curr]);
			send_input_events(element);
			value_arr_curr++;
}   }   }

function insert_to_form_index(menu_index) {
	let element_index = get_index_in_form();
	if (element_index === -1) return;
	// fill form
	let form_items = g_input_current.form.elements;
	for (let i = element_index; i < form_items.length && menu_index < g_menu_items.length; i++) {
		let element = form_items.item(i);
		if (is_input(element) && is_input_editable(element)) {
			let can_assign_value = 0;
			while (menu_index < g_menu_items.length) {
				let line_str = g_menu_items[menu_index];
				line_str = clear_menu_style(line_str);
				let menu_value = extract_menu_value(line_str);
				menu_value = validate_menu_value(menu_value);
				menu_index++;
				if (menu_value_is_valid(menu_value)) {
					can_assign_value = 1;
					break;
			}   }
			if (can_assign_value) {
				element.value = menu_value;
				send_input_events(element);
}   }   }   }

function validate_menu_value(menu_value) {
	if (g_browser_supported === 0) menu_value = chrome.i18n.getMessage("unknown_browser");
	return menu_value;
}

function send_input_events(element) {
	element.dispatchEvent(new KeyboardEvent('keydown', {key:'z', code:'KeyZ', bubbles: true}));
	element.dispatchEvent(new KeyboardEvent('keypress', {key:'z', code:'KeyZ', bubbles: true}));
	element.dispatchEvent(new InputEvent('input', {}));
	element.dispatchEvent(new KeyboardEvent('keyup', {key:'z', code:'KeyZ', bubbles: true}));
	element.dispatchEvent(new Event("change"));
}

function insert_to_input(menu_value, is_ctrl_key) {
	menu_value = validate_menu_value(menu_value);
	if (g_input_current === null) return;
	if (menu_value.indexOf("~~") !== -1) {
		insert_to_form_value(menu_value);
		return;
	}
	let is_div = false;
	let contenteditable = g_input_current.getAttribute("contenteditable");
	if (contenteditable !== null && contenteditable === "true") is_div = true;
	if (is_div) {
		if (document.hasFocus()) document.execCommand("insertHTML", false, menu_value);
	} else {
		let pos_to_select = 0;
		let s1 = "";
		let s2 = "";
		if (is_ctrl_key) {
			s1 = g_input_current.value.substr(0, g_input_current.selectionStart);
			s2 = g_input_current.value.substr(g_input_current.selectionEnd);
			pos_to_select = s1.length + menu_value.length;
		} else pos_to_select = menu_value.length;
		g_input_current.focus();
		g_input_current.value = s1 + menu_value + s2;
		g_input_current.setSelectionRange(pos_to_select,pos_to_select);
	}
	send_input_events(g_input_current);
}

function on_menu_item_click(event) {
	let menu_item = event.currentTarget;
	let index = menu_item.getAttribute("data-menu-index");
	menu_item_insert(index, event.shiftKey, event.ctrlKey);
	if (index === '65536') add_to_profile(event.ctrlKey);
	menu_off();
	event.stopPropagation();
}

function menu_item_neighbors_show() {
	if (g_neighbors_below === 0 || g_shift_is_pressed === 0) return;
	let menu_item_current = document.getElementById("informenter-menu-item-" + g_menu_index_selected);
	if (menu_item_current === null) return;
	menu_item_current = menu_item_current.nextSibling;	
	for (let i = 0; i < g_neighbors_below && menu_item_current; i++) {
		while (menu_item_current && !menu_item_current.classList.contains("informenter-menu-item"))
			menu_item_current = menu_item_current.nextSibling;	
		menu_item_current.classList.add("informenter-menu-item-below");
		menu_item_current = menu_item_current.nextSibling;	
}	}

function menu_item_neighbors_hide() {
	let menu_wrap = document.getElementById("informenter-menu");
	if (menu_wrap === null) return;
	let menu_item = menu_wrap.firstChild;
	while (menu_item) {
		if (menu_item.classList.contains("informenter-menu-item-below"))
			menu_item.classList.remove("informenter-menu-item-below");
		menu_item = menu_item.nextSibling;
}   }

function on_menu_item_over(event) {
	let menu_item = event.currentTarget;
	g_menu_index_selected = menu_item.getAttribute("data-menu-index");
	menu_item_neighbors_show();	
}

function on_menu_item_out(event) {
	menu_item_neighbors_hide();
}

function add_to_profile(is_ctrl_key) {
	if (g_input_current !== null) {
		let is_div = false;
		let contenteditable = g_input_current.getAttribute("contenteditable");
		if (contenteditable !== null && contenteditable === "true") is_div = true;
		let item_new = "";
		if (is_div) item_new = g_input_current.innerText;
		else item_new = g_input_current.value.trim();
		item_new = validate_menu_value(item_new);
		if (item_new.length > 0) {
			item_new = item_new.replace(/\n/g, "@@");
			chrome.runtime.sendMessage({msg:"add-menu-item", item_raw:item_new, to_head:is_ctrl_key});
}   }   }

function on_hotkey_click(command_str) {
	check_contenteditable_element();
	let command_num = parseInt(command_str.substr(17));
	let command_index = command_num - 1;
	if (g_enabled && g_input_current && g_menu_items && command_index > -1 && command_index < g_menu_items.length) 
		menu_item_insert(command_index, false, false);
	if (g_enabled && g_input_current && g_menu_items && command_num === 0) {
		let rect_input = g_input_current.getBoundingClientRect();
		g_menu_x = window.scrollX + rect_input.left + rect_input.width;
		g_menu_y = window.scrollY + rect_input.top;
		menu_show();
}   }

function on_context_menu_click(command_str) {
	check_contenteditable_element();
	let command_index = parseInt(command_str.substr(18)); // length of "context-menu-item-"
	if (g_enabled && g_input_current && g_menu_items && command_index > -1 && command_index < g_menu_items.length) 
		menu_item_insert(command_index, g_shift_is_pressed, g_ctrl_is_pressed);
	if (g_enabled && g_input_current && command_index === 65536) add_to_profile(g_ctrl_is_pressed);		
}

function on_marker_click(event) {
	if (g_input_current !== null) {
		g_menu_x = window.scrollX + event.clientX;
		g_menu_y = window.scrollY + event.clientY;
		menu_show();
		event.stopPropagation();
}   }

function on_marker_contextmenu(event) {
	g_marker_location++;
	if (g_marker_location > 3) g_marker_location = 0;
	g_marker_shifting = 1;
	chrome.runtime.sendMessage({msg:"change-marker-location", marker_location:g_marker_location});
	event.preventDefault();
	event.stopPropagation();
}

function menu_show() {
	let menu_wrap = create_menu_wrap();
	for (let i = 0; i < g_menu_items.length; i++) {
		let line_str = g_menu_items[i];
		let menu_style = extract_menu_style(line_str);
		line_str = clear_menu_style(line_str);
		let menu_item_name = extract_menu_name(line_str);
		create_menu_item(menu_wrap, menu_item_name, i, menu_style);
	}
	create_menu_special_items(menu_wrap);
	check_menu_position(menu_wrap);
	g_menu_index_selected = -1;
}

function menu_select_next() {
	let try_num = 0;
	while (try_num < g_menu_items.length) {
		g_menu_index_selected++;
		if (g_menu_index_selected >= g_menu_items.length) g_menu_index_selected = 0;
		let id_to_select = "informenter-menu-item-" + g_menu_index_selected;
		let menu_item = document.getElementById(id_to_select);
		if (menu_item) {
			menu_item.focus();	
			break;
		}
		try_num++;
}   }

function menu_select_prev() {
	let try_num = 0;
	while (try_num < g_menu_items.length) {
		g_menu_index_selected--;
		if (g_menu_index_selected < 0) g_menu_index_selected = g_menu_items.length-1;
		let id_to_select = "informenter-menu-item-" + g_menu_index_selected;
		let menu_item = document.getElementById(id_to_select);
		if (menu_item) {
			menu_item.focus();	
			break;
		}
		try_num++;
}   }

function menu_select_current(is_shift_key, is_ctrl_key) {
	let id_to_select = "informenter-menu-item-" + g_menu_index_selected;
	let menu_item = document.getElementById(id_to_select);
	if (menu_item) menu_item_insert(g_menu_index_selected, is_shift_key, is_ctrl_key);
	menu_off();
}

function menu_off() {
	let menu_wrap = document.getElementById("informenter-menu");
	if (menu_wrap) menu_wrap.parentNode.removeChild(menu_wrap);
}

function check_active_element() {
	let element = document.activeElement;
	if (element && is_input(element) && is_input_editable(element)) marker_show(element);
}

function check_contenteditable() {
	let contenteditable = document.body.getAttribute("contenteditable");
	if (contenteditable === true || contenteditable === "true" || contenteditable === "") marker_remove();	
}

window.setTimeout(check_active_element,  200);
window.setTimeout(check_contenteditable, 500);

function on_messages_content(request, sender, sendResponse) {
	if (sender.id !== chrome.runtime.id) return;
	if (request.msg === "data-ready") {
		if (request.ready) chrome.runtime.sendMessage({msg:"get-page-data"});
		else window.setTimeout(chrome.runtime.sendMessage({msg:"is-data-ready"}), 1000);
	}	
	if (request.msg === "set-page-data") {
		g_menu_items = request.menu.split("\n");
		g_marker_location = request.marker_location;
		g_marker_image = request.marker_image;
		g_last_password = request.password;
		g_enabled = request.enabled;
		g_browser_supported = request.browser_supported;
		menu_off();
		marker_remove();
		if (g_enabled) {
			marker_create();
			if (g_marker_shifting) marker_show(g_input_current);
		}
		g_marker_shifting = 0;
	}
	if (request.msg === "set-last-password") g_last_password = request.password;
	if (request.msg === "close-menu") menu_off();
	if (request.msg === "hide-marker") marker_hide_on_page();
	if (request.msg === "hotkey-click") on_hotkey_click(request.command);
	if (request.msg === "context-menu-click") on_context_menu_click(request.command);
}

chrome.runtime.onMessage.addListener(on_messages_content);
chrome.runtime.sendMessage({msg:"is-data-ready"});

document.addEventListener("click", on_document_click); 
document.addEventListener("keydown", on_document_keydown); 
document.addEventListener("keyup", on_document_keyup); 
window.addEventListener("beforeprint", on_window_beforeprint); 
window.addEventListener("afterprint", on_window_afterprint); 
window.addEventListener("scroll", on_window_scroll);
window.addEventListener("resize", on_window_resize);
